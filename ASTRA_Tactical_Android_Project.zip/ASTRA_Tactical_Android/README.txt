ASTRA TACTICAL — Android project
This project is an APK-ready Android Studio/WebView wrapper containing the lightweight FPS prototype.
The supplied screenshots were used as the visual reference: landscape first-person view, sniper/AR HUD, FFA timer, HP/ammo UI and touch-friendly controls.

Build:
1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Build > Build APK(s).
4. Install the generated debug APK on your Android phone.

The game itself is local and uses no server. Internet permission is included only because the project can be extended with online assets/features.
